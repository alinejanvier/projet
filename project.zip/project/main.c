#include "ch.h"
#include "chprintf.h"
#include "hal.h"
#include "shell.h"

#include "aseba_vm/aseba_node.h"
#include "audio/audio_thread.h"
#include "audio/microphone.h"
#include "sensors/imu.h"
#include "sensors/proximity.h"
#include "leds.h"
#include "motors.h"
#include "audio_processing.h"
#include <main.h>

const int speed = 1000;
const int prox_max = 3800;
const int prox_max_arriere = 2000;
const int prox_min = 200;
const int gravitation_inverse_min = 14000;
const int step_per_cm = 85;
const double diametre_rotation = 15.7;

static bool bounce_enabled = false;
static bool start_enabled = true;

messagebus_t bus;
MUTEX_DECL(bus_lock);
CONDVAR_DECL(bus_condvar);

#define STACK_CHK_GUARD 0xe2dee396
uintptr_t __stack_chk_guard = STACK_CHK_GUARD;

void __stack_chk_fail(void){
    chSysHalt("Stack smashing detected");
}

//basic function to make the robot turn around a certain angle
void turn(double angle){
	if(angle > 180){
		angle -= 360;
	}
	if(angle < -180){
		angle += 360;
	}

	right_motor_set_speed(0);
	left_motor_set_speed(0);
	left_motor_set_pos(0);
	right_motor_set_pos(0);
	if(angle > 0){
		right_motor_set_speed(speed);
		left_motor_set_speed(-speed);
		while(-left_motor_get_pos() < step_per_cm*(diametre_rotation*angle/360)){
			chThdSleepMilliseconds(10);
		}
	}
	else{
		right_motor_set_speed(-speed);
		left_motor_set_speed(speed);
		while(left_motor_get_pos() < step_per_cm*(-diametre_rotation*angle/360)){
			chThdSleepMilliseconds(10);
		}
	}
	right_motor_set_speed(0);
	left_motor_set_speed(0);
}

//function that calculates the weighted average of the proximity sensors' angles using their respective
// measured values as weights (see report to understand why sensors 3 and 4 are treated differently)
double incidence_angle(){
	double sum = 0;
	double angle = 0;
	int z;

	z = get_prox(0);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*22.5;
	}
	z = get_prox(1);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*67.5;
	}
	z = get_prox(2);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*112.5;
	}
	z = get_prox(3);
	if(z < prox_max_arriere && z > prox_min){
		sum += z;
		angle += z*170;
	}
	z = get_prox(4);
	if(z < prox_max_arriere && z > prox_min){
		sum += z;
		angle += z*-170;
	}
	z = get_prox(5);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*-112.5;
	}
	z = get_prox(6);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*-67.5;
	}
	z = get_prox(7);
	if(z < prox_max && z > prox_min){
		sum += z;
		angle += z*-22.5;
	}
	return angle/sum;
}

//function that checks if the robot has been turned upside-down
bool goal(){
	int acc = get_acc(2);
	if(acc > gravitation_inverse_min){
		return true;
	}
	return false;
}

//function that receives the incidence angle and calls turn() with a calculated angle (see report)
void bounce(){
	double angle = incidence_angle();

	if(angle >= 0 && angle <= 90){
		turn(180-angle*2);
	}
	else if(angle >= -90 && angle < 0){
		turn(-180-angle*2);
	}
	else if(angle >= -180 && angle < -90){
		turn((-180-angle)/2);
	}
	else if(angle > 90 && angle < 180){
		turn((180-angle)/2);
	}
	right_motor_set_speed(speed);
	left_motor_set_speed(speed);
}

//function that goes through the starting steps of every playing round; count-down and random direction chooser
void start(){
	for(int i = 0; i < 3; i++){
		chThdSleepMilliseconds(800);
		set_led(-1,1);
		dac_play(402);
		chThdSleepMilliseconds(300);
		set_led(-1,0);
		dac_stop();
	}
	chThdSleepMilliseconds(800);
	while(true){
		turn(15);
		if(whistle())
			break;
	}
	set_body_led(1);
	right_motor_set_speed(speed);
	left_motor_set_speed(speed);
	bounce_enabled = true;
}

static THD_WORKING_AREA(BounceThreadWorkingArea, 128);
static THD_WORKING_AREA(GoalThreadWorkingArea, 128);

//Thread taking care of bouncing while driving (see report to understand why sensors 3 and 4 are treated differently)
static THD_FUNCTION(BounceThread, arg){
	(void)arg;
	int z;
	while(true){
		chThdSleepMilliseconds(100);
		if(bounce_enabled){
			bounce_enabled = false;
			for(int i = 0; i < 8; i++){
				z =  get_prox(i);
				if(z > prox_min  && (z < prox_max_arriere || (z < prox_max && i != 3 && i != 4))){
					set_front_led(1);
					bounce();
					set_front_led(0);
					break;
				}
			}
			bounce_enabled = true;
		}
	}
}

//Thread checking the goal() function and if needed it triggers a new round by calling start()
static THD_FUNCTION(GoalThread, arg){
	(void)arg;
	while(true){
		chThdSleepMilliseconds(100);
		if(start_enabled && goal()){
			start_enabled = false;
			bounce_enabled = false;
			right_motor_set_speed(0);
			left_motor_set_speed(0);
			set_body_led(0);
			chThdSleepMilliseconds(5000);
			start();
			bounce_enabled = true; //also already enabled by start()
			start_enabled = true;
		}
	}
}

int main(void){

	halInit();
	chSysInit();

    //initializes the Inter Process Communication bus
    messagebus_init(&bus, &bus_lock, &bus_condvar);

    //initializes the peripherals
	clear_leds();
	set_body_led(0);
	set_front_led(0);
	motors_init();
	proximity_start();
	dac_start();
	imu_start();
	mic_start(&processAudioData);

	//Start the game
    start();

    //Start the Bounce and Goal Threads
	(void)chThdCreateStatic(BounceThreadWorkingArea, sizeof(BounceThreadWorkingArea), NORMALPRIO, BounceThread, NULL);
	(void)chThdCreateStatic(GoalThreadWorkingArea, sizeof(GoalThreadWorkingArea), NORMALPRIO, GoalThread, NULL);
}
