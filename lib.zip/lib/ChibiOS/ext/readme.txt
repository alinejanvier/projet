All the code contained under ./ext is not part of the ChibiOS project and
supplied as-is without any additional warranty by ChibiOS. For ownership and
copyright statements see the license details inside the code.

Some modules may contain changes from the ChibiOS team in order to increase
compatibility or usability with ChibiOS itself.
